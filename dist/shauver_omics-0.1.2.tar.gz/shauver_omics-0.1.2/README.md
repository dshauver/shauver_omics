# shauver_omics Package
A collection of useful Python functions for *omics analysis.

## Installation
```bash
pip install shauver_omics